import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import pickle
from data_preprocessing import preprocess_data  # Importing the preprocess_data function

# Preprocess the data
X_train, X_test, y_train, y_test = preprocess_data()

# Train the model
model = RandomForestRegressor(random_state=42)
model.fit(X_train, y_train)

# Save the model with error handling
try:
    with open("D:/Project/model.pkl", "wb") as f:
        pickle.dump(model, f)
    print("Model saved successfully!")
except PermissionError as e:
    print(f"Permission error: {e}")
except Exception as e:
    print(f"An error occurred: {e}")
