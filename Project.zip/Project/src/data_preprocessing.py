import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
import pickle

def preprocess_data():
    # Load datasets
    calories_data = pd.read_csv("D:/Project/data/calories.csv")
    exercise_data = pd.read_csv("D:/Project/data/exercise.csv")

    # Merge datasets on 'User_ID'
    data = pd.merge(exercise_data, calories_data, on="User_ID")

    # Handle missing values (if any)
    data = data.dropna()

    # Encode categorical 'Gender' column (male: 0, female: 1)
    label_encoder = LabelEncoder()
    data['Gender'] = label_encoder.fit_transform(data['Gender'])

    # Select features and target
    X = data.drop(columns=["Calories", "User_ID"])  # Drop 'Calories' as it's the target, 'User_ID' is not needed
    y = data["Calories"]

    # Print the shape of X to confirm the number of features
    print(f"Shape of X: {X.shape}")  # It should show (num_samples, 7) or similar

    # Standardize numerical features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)  # X_scaled will be a 2D array (num_samples, 7)

    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # Save the scaler for future use
    with open('D:/Project/scaler.pkl', 'wb') as f:
        pickle.dump(scaler, f)

    return X_train, X_test, y_train, y_test

# Call preprocess function to run and check
X_train, X_test, y_train, y_test = preprocess_data()
